using System;
using System.Threading;

const int StackSize = 128 * 1024 * 1024;
int exitCode = 0;
Thread thread = new Thread(() => {
    try {
        // Test 1: Parametric sum type (the bug)
        string src1 = "Result (a) =\n  | Success (a)\n  | Failure (Text)\n\nsafe-divide : Integer -> Integer -> Result Integer\nsafe-divide (x) (y) = if y == 0 then Failure \"division by zero\" else Success (x / y)\n\ndescribe : Result Integer -> Text\ndescribe (result) = when result if Success (n) -> \"got \" ++ show n if Failure (msg) -> \"error: \" ++ msg\n\nmain : Text\nmain = describe (safe-divide 42 7)";
        Console.WriteLine("=== Test 1: Parametric sum type with type annotations ===");
        Console.WriteLine(Codex_Codex_Codex.compile(src1, "test1"));

        // Test 2: Non-parametric sum type
        string src2 = "Color =\n  | Red\n  | Blue\n  | Green\n\nname : Color -> Text\nname (c) = when c if Red -> \"red\" if Blue -> \"blue\" if Green -> \"green\"\n\nmain : Text\nmain = name Red";
        Console.WriteLine("=== Test 2: Non-parametric sum type ===");
        Console.WriteLine(Codex_Codex_Codex.compile(src2, "test2"));

        // Test 3: Record type
        string src3 = "Point = record {\n  x : Integer,\n  y : Integer\n}\n\ndist : Point -> Integer\ndist (p) = p.x + p.y\n\nmain : Integer\nmain = dist (Point { x = 3, y = 4 })";
        Console.WriteLine("=== Test 3: Record type ===");
        Console.WriteLine(Codex_Codex_Codex.compile(src3, "test3"));

        exitCode = 0;
    } catch (Exception ex) {
        Console.Error.WriteLine($"FAILED: {ex.GetType().Name}: {ex.Message}");
        Console.Error.WriteLine(ex.StackTrace);
        exitCode = 1;
    }
}, StackSize);
thread.Start();
thread.Join();
return exitCode;
